//
//  ViewController.swift
//  0516
//
//  Created by User17 on 2018/5/16.
//  Copyright © 2018年 User17. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    

    @IBOutlet weak var fatText: UITextField!
    
    @IBOutlet weak var longText: UITextField!
    
    @IBOutlet weak var BMIText: UILabel!
    
    @IBOutlet weak var sayText: UILabel!
    
    @IBAction func calculateBMI(_ sender: Any){
        if let fatT = fatText.text,
        let longT = longText.text,
        let weight = Double(fatT),
        let height = Double(longT){
            let BMI = String(format:"%.2f",weight/(height*height/10000))
            BMIText.text = "\(BMI)"
            if weight/(height*height/10000) < 18.5
            {
                sayText.text = "小寶貝多吃點"
            }
            else if weight/(height*height/10000) > 28
            {
                sayText.text = "你很貪吃"
            }
            else
            {
                sayText.text = "跟我一樣健康！"
            }
        }
    }
    
    @IBAction func dismissKeyboard(_ sender: UIButton) {
        view.endEditing(true)
    }
    
    @IBAction func byeKeyboard(_ sender: UITextField) {
        sender.resignFirstResponder()
    }
    
    @IBAction func viewTap(_ sender: Any) {
        view.endEditing(true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

