//
//  ColorController.swift
//  ０５０２
//
//  Created by User17 on 2018/5/2.
//  Copyright © 2018年 User17. All rights reserved.
//

import UIKit

class ColorController: UIViewController {

    @IBOutlet weak var ViewBack: UIImageView!
    
    @IBOutlet weak var redSlider: UISlider!
    
    @IBOutlet weak var blueSlider: UISlider!
    
    @IBOutlet weak var greenSlider: UISlider!
    
    @IBOutlet weak var alphaSlider: UISlider!
    
    @IBOutlet weak var redLabel: UILabel!
    
    @IBOutlet weak var blueLabel: UILabel!
    
    @IBOutlet weak var greenLabel: UILabel!
    
    @IBOutlet weak var alphaLabel: UILabel!
    
    @IBAction func silderChange(_ sender: UISlider) {
        ViewBack.backgroundColor = UIColor(red: CGFloat(redSlider.value), green: CGFloat(greenSlider.value), blue: CGFloat(blueSlider.value), alpha: CGFloat(alphaSlider.value))
        if sender == redSlider
        {
            if redSlider.value*255 < 50
            {
                redLabel.text = "還算健康"
            }
            else if redSlider.value*255 < 150 && redSlider.value*255 > 52
            {
                redLabel.text = "生病囉"
            }
            else if redSlider.value*255 > 150 && redSlider.value*255 < 255
            {
                redLabel.text = "沒救囉"
            }
        }
        else if sender == blueSlider
        {
            var blueValue = String(format:"%.0f",blueSlider.value*255);
            blueLabel.text = "\(blueValue)"
        }
        else if sender == greenSlider
        {
            var greenValue = String(format:"%.0f",greenSlider.value*255);
            greenLabel.text = "\(greenValue)"
        }
        else if sender == alphaSlider
        {
            var alphaValue = String(format:"%.2f",alphaSlider.value);
            alphaLabel.text = "\(alphaValue)"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
